
package MenuPrincipal;

import finalproyect.Tablero;
//import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Guardar_Abrir {
    private Tablero tableroG;
    private ObjectOutputStream guardado;
    private ObjectInputStream open;
    private JFileChooser guardo;
    private File direccion;

    public Guardar_Abrir(Tablero tableroG) {
        this.tableroG = tableroG;
    }

    public Guardar_Abrir() {
    }
    

    private void hallarPath(String extension){
        
        guardo = new JFileChooser();
        guardo.setApproveButtonText("Guardar");
        FileNameExtensionFilter filtro=new FileNameExtensionFilter(".board","board");
        guardo.setFileFilter(filtro);
        
        //guardo.setCurrentDirectory(direc);
        guardo.showSaveDialog(null);
        
        direccion = guardo.getSelectedFile();
        
         
//        String nameExt="";
//        String nombre = tableroG.getNombreJuego();
//        if(nombre.length()>=5){
//            if (!nombre.substring(nombre.length()-5, nombre.length()).equalsIgnoreCase(extension)) {
//                nameExt="src/JG/"+nombre+extension;
//            }            
//        }else{
//            nameExt="src/JG/"+nombre+extension;
//        }
//        File direc = new File(nameExt);
//        path = direccion.getAbsolutePath();
//        
    }
    
    
    public void guardarTablero(String extension){
        
        hallarPath(extension);
        try {
                guardado = new ObjectOutputStream(new FileOutputStream(direccion));
                //tableroG.setVisible(true);
                guardado.writeObject(tableroG);
                JOptionPane.showMessageDialog(null, "El Tablero "+tableroG.getNombreJuego()+" se ha guardado con exito.");
                guardado.close();
                           
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "No se ha podido guardar el archivo.");
        }
        
    }
    public void abrirTablero(String extension) {
        guardo = new JFileChooser();
        guardo.setApproveButtonText("Abrir");
        guardo.showOpenDialog(null);
        
        direccion =guardo.getSelectedFile();
        
        
        try {
            open = new ObjectInputStream(new FileInputStream(direccion));
            tableroG= (Tablero)open.readObject();
            tableroG.setVisible(true);
            Editar guardando = new Editar(tableroG);
            guardando.guardarTablero();
            open.close();
        } catch (IOException ex) {            
            JOptionPane.showMessageDialog(null, "No se ha encontrado el archivo.");
        } catch(ClassNotFoundException t){
            JOptionPane.showMessageDialog(null, "La clase que buscas no existe");
            
        }
        
    }

    public Tablero getTableroG() {
        return tableroG;
    }

    public void setTableroG(Tablero tableroG) {
        this.tableroG = tableroG;
    }
    
    
    
}
