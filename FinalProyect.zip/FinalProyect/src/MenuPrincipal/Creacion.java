
package MenuPrincipal;

//import com.sun.imageio.plugins.jpeg.JPEG;
//import finalproyect.Menu;

import finalproyect.Casilla;
import finalproyect.Tablero;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
//import javax.swing.JFrame;
import javax.swing.JPanel;

public class Creacion implements ActionListener{
    private Tablero tableroC;
    private JButton guardarC;
    
   
    
    private JPanel panelC;
    

    public Creacion(Tablero tableroC) {
        this.tableroC = tableroC;
        
    }

    

    public Tablero getTableroC() {
        return tableroC;
    }

    public void setTableroC(Tablero tableroC) {
        this.tableroC = tableroC;
    }


    public JPanel getPanelC() {
        return panelC;
    }

    public void setPanelC(JPanel panelC) {
        this.panelC = panelC;
    }
    
 
    
    public void crearTablero(){
        tableroC.iniciarComponentes();
        guardarTablero();
    }

    
    private void guardarTablero(){
        panelC = new JPanel();
        guardarC=new JButton();
        panelC= tableroC.getPanelPri();
        guardarC = tableroC.getBotonGuardar();
        guardarC.addActionListener(this);
        guardarC.setVisible(true);
        tableroC.add(panelC);
        tableroC.setVisible(true);
    }
   
    @Override
    public void actionPerformed(ActionEvent e) {
        tableroC.setVisible(false);
        guardarC.setVisible(true);
        Guardar_Abrir save = new Guardar_Abrir(tableroC);
        save.guardarTablero(".board");
    
        
    }

}
