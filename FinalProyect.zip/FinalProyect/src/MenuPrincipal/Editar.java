
package MenuPrincipal;

import finalproyect.Menu;
import finalproyect.Tablero;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;


public class Editar implements ActionListener {
    private JButton guardarE;
    private Tablero ediTablero;
    private JPanel panelE;

    public Editar(Tablero ediTablero) {
        this.ediTablero = ediTablero;
    }

    public JButton getGuardarE() {
        return guardarE;
    }

    public void setGuardarE(JButton guardar) {
        this.guardarE = guardar;
    }
    

    public Tablero getEdiTablero() {
        return ediTablero;
    }

    public void setEdiTablero(Tablero ediTablero) {
        this.ediTablero = ediTablero;
    }
    
    public void guardarTablero(){
        panelE=ediTablero.getPanelPri();
        guardarE = ediTablero.getBotonGuardar();
        guardarE.setText("Cambios");
        guardarE.addActionListener(this);
        guardarE.setVisible(true);
        ediTablero.add(panelE);
        ediTablero.setVisible(true);
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        ediTablero.setVisible(false);
        guardarE.setVisible(false);
        Guardar_Abrir save = new Guardar_Abrir(ediTablero);
        save.guardarTablero(".board");
   }
    
}
