
package finalproyect;


public class Dado {
    private int numero;

    public Dado() {
    }
    
    public int tirarDado(){
        numero =(int)(Math.random()*6+1);
        switch(numero){
            
        }
        
        return numero;
    }
    public int verificarDobles(int []dados){
        boolean doble ;
        while(doble = true){
            if(dados[0] != dados[1]){
                doble= false;
            }else{
                
            }
        }
        return 0;
    }
    
}
