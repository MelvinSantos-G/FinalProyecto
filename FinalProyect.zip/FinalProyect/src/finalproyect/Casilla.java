
package finalproyect;

import Casillas.Carcel;
import Casillas.Propiedad;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;



public class Casilla extends JButton implements ActionListener {
    private String nombre;
    private Color colorCasilla ;
    private  final int tamañoCasilla=100;
    private JLabel etiBoton;
    private int posicion;
    private  int xi;
    private  int yi;
    private boolean estado;

    public Casilla(int posicion,int x, int y) {
       
        this.posicion = posicion;
        this.xi = x;
        this.yi=y;
    }   

    public Casilla() {
        
    }
    
    public void crearBoton(int tamaño, String texto){
        etiBoton = new JLabel();
        setLayout(null);        
        addActionListener(this);
        setBounds(xi,yi , tamaño, tamaño);
        setText(texto);
        setBackground(Color.WHITE);
        
    }

    public int getPosicion() {
        return posicion;
    }
   
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Color getcolorCasilla() {
        return colorCasilla;
    }

    public void setcolorCasilla(Color colorCasilla) {
        etiBoton.setBackground(colorCasilla);        
    }

    public JLabel getEtiBoton() {
        return etiBoton;
    }

    public void setEtiBoton(JLabel etiBoton) {
        this.etiBoton = etiBoton;
    }

    public int getTamañoCasilla() {
        return tamañoCasilla;
    }

    public int getXi() {
        return xi;
    }

    public int getYi() {
        return yi;
    }

    
    
    
   
    @Override
    public void actionPerformed(ActionEvent e) {                
        etiBoton.setOpaque(false);
        etiBoton.setText("");
        Propiedad h= new Propiedad(posicion,xi,yi);
        h.editarPropiedad();        
        etiBoton=h.getCambicolor();
        setVisible(true);
        add(etiBoton);
       

    }
    
    
}
