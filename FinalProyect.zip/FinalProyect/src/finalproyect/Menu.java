
package finalproyect;

import MenuPrincipal.Creacion;
import MenuPrincipal.Guardar_Abrir;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class Menu extends JFrame implements ActionListener{
    public Tablero tablero;
    private int altura;
    private int ancho;
    private JPanel panelMenu;
    private JButton booton;
    private JButton booton2;
    public Menu() {
        
    }

    public void iniciarComponentesMenu(){
        iniciarVentana();
        iniciarPanel();
        setVisible(true);
    }
    private void iniciarVentana(){
        Toolkit ventanaT = Toolkit.getDefaultToolkit();
        Dimension tamaVentana = ventanaT.getScreenSize();
        altura = tamaVentana.height-200;
        ancho = tamaVentana.width/2; 
        setSize(ancho, altura);
        setTitle("CHALANOPOLY");
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    private void iniciarPanel (){
        ImageIcon imag= new ImageIcon("src/Imagenes/usac.png");
        panelMenu= new JPanel();
        panelMenu.setLayout(null);
        JLabel etImagen= new JLabel(new ImageIcon());
        etImagen.setBounds(0, 0, ancho, altura);
        etImagen.setIcon(new ImageIcon(imag.getImage().getScaledInstance(ancho, altura, Image.SCALE_SMOOTH)));
        booton = new JButton("Crear Juego");
        booton.setBounds(20, 20, 150, 50);
        booton.setBackground(Color.DARK_GRAY);
        booton.addActionListener(this);
        booton2 = new JButton("Editar");
        booton2.setBounds(200, 20, 150, 50);
        booton.setBackground(Color.YELLOW);
        booton2.addActionListener(this);
        panelMenu.add(booton2);
        panelMenu.add(booton);
        panelMenu.add(etImagen);
        add(panelMenu);
           
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton accion = (JButton)e.getSource();
        if (accion ==booton) {
            //setVisible(f;
            tablero = new Tablero();
            Creacion creaTablero = new Creacion(tablero);
            creaTablero.crearTablero();
        }
        if (accion ==booton2) {
            Guardar_Abrir abrir = new Guardar_Abrir();
            abrir.abrirTablero(".board");
            
        }

        
        
    }
    
    
}
