
package finalproyect;


public class Jugador {
    
    private String nombre;
    private String [] propiedades;
    private int dinero;
    private boolean bancarrota;

    public Jugador() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String[] getPropiedades() {
        return propiedades;
    }

    public void setPropiedades(String[] propiedades) {
        this.propiedades = propiedades;
    }

    public int getDinero() {
        return dinero;
    }

    public void setDinero(int dinero) {
        this.dinero = dinero;
    }

    public boolean isBancarrota() {
        return bancarrota;
    }

    public void setBancarrota(boolean bancarrota) {
        this.bancarrota = bancarrota;
    }
    
    
    
    
}
