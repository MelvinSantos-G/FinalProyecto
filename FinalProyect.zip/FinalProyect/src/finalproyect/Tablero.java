package finalproyect;

import Casillas.Inicio;
import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Tablero extends JFrame {

    private String nombreJuego;
    private int cantJugadores;
    private int cantDineroInicio;
    private int cantDineroVuelta;
    private int cantDados;
    private int limiteCasas;
    private int limiteHoteles;
    private float porcentajeHipo;

    private JButton botonGuardar;
    private JPanel panelPri;
    private int altura;
    private int ancho;
    private Casilla[] posiCasillas;
    private Casilla nuevaCasilla;
    private final int tamañoCasi = 100;
    private final int sangria = 110;

    public Tablero() {

    }

    private void iniciarValores() {
        nombreJuego = pedirNombre();
        cantJugadores = pedirCantidadJugadores();
        cantDineroInicio = pedirCantidadDineroInicio();
        cantDineroVuelta = pedirCantidadDineroPorVuelta();
        cantDados = pedirCantidadDados();
        limiteCasas = pedirLimiteCasas();
        limiteHoteles = pedirLimiteHoteles();
        porcentajeHipo = pedirPorcentajeHIpoteca();

    }

    private void iniciarVentana() {
        Toolkit ventanaT = Toolkit.getDefaultToolkit();
        Dimension tamaVentana = ventanaT.getScreenSize();
        altura = tamaVentana.height;
        ancho = tamaVentana.width;
        setSize(ancho, altura);
        setTitle("Nuevo");
        setLocationRelativeTo(null);
       
    }

    public void iniciarComponentes() {
        iniciarVentana();
        iniciarValores();
        int numHor = pedirTamañoHorizontal();
        int numVer = pedirTamañoVertical();
        int tamañoArreglo = 2 * (numHor + numVer);
        panelPri = new JPanel();
        panelPri.setLayout(null);
        posiCasillas = new Casilla[tamañoArreglo];
        int valor;

        for (int i = 0; i < tamañoArreglo; i++) {
            //primera fila

            if (numHor > i) {
               
                int x = tamañoCasi * (numHor - 1 - i) + sangria;
                int y = (numVer + 1) * tamañoCasi + sangria;
                int condicion2 = numHor / 2;

                if (numHor % 2 == 0) {
                    int condicion1 = condicion2 - 1;
                    y = crearCurva(i, y, tamañoCasi, condicion1, condicion2);
                } else {
                    y = crearCurva(i, y, tamañoCasi, condicion2, condicion2);
                }
                crearCasillas(x, y, i);
            }
            // primera columna
            valor = numHor + numVer;
            if (numHor <= i && valor > i) {
                int j = i - numHor;
                int x = sangria;
                int y = tamañoCasi * (numVer - j) + sangria;
                int condicion2 = numHor + numVer / 2;
                if (numVer % 2 == 0) {
                    int condicion1 = condicion2 - 1;
                    x = crearCurva(i, x, -tamañoCasi, condicion1, condicion2);
                } else {
                    x = crearCurva(i, x, -tamañoCasi, condicion2, condicion2);
                }
                crearCasillas(x, y, i);
            }
            //segunda fila
            if (valor <= i && valor + numHor > i) {
                int x = tamañoCasi * (i - valor) + sangria;
                int y = sangria;
                int condicion2 = valor + numHor / 2;

                if (numHor % 2 == 0) {
                    int condicion1 = condicion2 - 1;
                    y = crearCurva(i, y, -tamañoCasi, condicion1, condicion2);
                } else {
                    y = crearCurva(i, y, -tamañoCasi, condicion2, condicion2);
                }
                crearCasillas(x, y, i);
            }
            // segunda columna
            if (valor + numHor <= i && 2 * valor > i) {
                int j = i - (valor + numHor);
                int x = tamañoCasi * (numHor - 1) + sangria;
                int y = tamañoCasi * (j + 1) + sangria;
                int condicion2 = (valor + numHor) + numVer / 2;
                if (numVer % 2 == 0) {
                    int condicion1 = condicion2 - 1;
                    x = crearCurva(i, x, tamañoCasi, condicion1, condicion2);
                } else {
                    x = crearCurva(i, x, tamañoCasi, condicion2, condicion2);
                }
                crearCasillas(x, y, i);
            }
        }
        posiCasillas = imprimirFilaColumna1(posiCasillas, tamañoArreglo);
        botonGuardar = new JButton("Guardar cambios");
        botonGuardar.setBounds(ancho - 300, altura - 200, 250, 40);
        panelPri.add(botonGuardar);

        add(panelPri);
        panelPri.setVisible(true);

    }

    private void crearCasillas(int x, int y, int i) {
        if (i==0) {
            posiCasillas[i] = new Inicio(cantDineroVuelta, i,x,y);
        }else{
        posiCasillas[i] = new Casilla( i, x, y);
        posiCasillas[i].crearBoton(tamañoCasi, ""+i);
        }
    }

    private Casilla[] imprimirFilaColumna1(Casilla[] casillas, int num) {
        for (int i = 0; i < num; i++) {
            panelPri.add(casillas[i]);
        }
        return casillas;
    }

    private int pedirTamañoVertical() {
        int limite = (altura / tamañoCasi) - 1;
        int vertical;
        try {
            vertical = Integer.parseInt(JOptionPane.showInputDialog("Ingresa el tamaño del Tablero "
                    + nombreJuego + "\n\nIngresa el tamaño Vertical entre 6--" + limite + ":"));
            if (vertical < 6 || vertical > limite) {
                JOptionPane.showMessageDialog(null, "ERROR. El valor ingresado no esta en el rango permitido.");
                vertical = pedirTamañoVertical();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ERROR. Vuelve a intentarlo");
            vertical = pedirTamañoVertical();
        }

        return vertical - 2;
    }

    private int pedirTamañoHorizontal() {
        int limite = (ancho / tamañoCasi) - 5;
        int horizontal;
        try {
            horizontal = Integer.parseInt(JOptionPane.showInputDialog("Ingresa el tamaño del Tablero "
                    + nombreJuego + "\n\nIngresa el tamaño Horizontal entre 7--" + limite + ":"));
            if (horizontal < 7 || horizontal > limite) {
                JOptionPane.showMessageDialog(null, "ERROR. El valor ingresado no esta en el rango permitido.");
                horizontal = pedirTamañoHorizontal();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ERROR. Vuelve a intentarlo");
            horizontal = pedirTamañoHorizontal();
        }

        return horizontal;
    }

    private int crearCurva(int i, int valor, int tamaño, int cond1, int cond2) {
        if (i == cond1 || i == cond2) {
            valor -= tamaño;
        }
        return valor;
    }

    private String pedirNombre() {
        String name;
        try {
            name = JOptionPane.showInputDialog("Ingresa el nombre del juego");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ERROR. Vuelve a intentarlo");
            name = pedirNombre();
        }

        return name;
    }

    private int pedirCantidadJugadores() {
        int num;
        try {
            num = Integer.parseInt(JOptionPane.showInputDialog
            ("Ingresa el numero de Jugadores para el Tablero "+ nombreJuego+"\nentre 2--6"));
            if (num < 2 || num > 6) {
                JOptionPane.showMessageDialog(null, "ERROR. Valor ingresado no valido");
                num = pedirCantidadJugadores();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ERROR. Vuelve a intentarlo");
            num = pedirCantidadJugadores();
        }
        return num;
    }

    private int pedirCantidadDineroInicio() {
        int num;
        try {
            num = Integer.parseInt(JOptionPane.showInputDialog
        ("Ingresa la cantidad inicial de dinero para cada jugador"));
            if (num <= 0) {
                JOptionPane.showMessageDialog(null, "ERROR. Valor ingresado no valido");
                num = pedirCantidadDineroInicio();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ERROR. Vuelve a intentarlo");
            num = pedirCantidadDineroInicio();
        }

        return num;
    }

    private int pedirCantidadDineroPorVuelta() {
        int num;
        try {
            num = Integer.parseInt(JOptionPane.showInputDialog
            ("¿Cuanto dinero recibiras al pasar por la casilla de inicio?"));
            if (num < 0) {
                JOptionPane.showMessageDialog(null, "ERROR. Valor ingresado no valido");
                num = pedirCantidadDineroPorVuelta();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ERROR. Vuelve a intentarlo");
            num = pedirCantidadDineroPorVuelta();
        }
        return num;
    }

    private int pedirCantidadDados() {
        int num;
        try {
            num = Integer.parseInt(JOptionPane.showInputDialog
            ("Ingresa la cantidad de dados para el Tablero " + nombreJuego+"\nentre 1--3"));
            if (num < 1 || num > 3) {
                JOptionPane.showMessageDialog(null, "ERROR. Valor ingresado no valido");
                num = pedirCantidadDados();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ERROR. Vuelve a intentarlo");
            num = pedirCantidadDados();
        }

        return num;
    }

    private int pedirLimiteCasas() {
        int num;
        try {
            num = Integer.parseInt(JOptionPane.showInputDialog
            ("Ingresa el limite de Casas por Propiedad"));
            if (num < 0) {
                JOptionPane.showMessageDialog(null, "ERROR. Valor ingresado no valido");
                num = pedirLimiteCasas();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ERROR. Vuelve a intentarlo");
            num = pedirLimiteCasas();
        }

        return num;
    }

    private int pedirLimiteHoteles() {
        int num;
        try {
            num = Integer.parseInt(JOptionPane.showInputDialog
            ("Ingresa el limite de Hoteles por Propiedad "));
            if (num < 0) {
                JOptionPane.showMessageDialog(null, "ERROR. Valor ingresado no valido");
                num = pedirLimiteHoteles();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ERROR. Vuelve a intentarlo");
            num = pedirLimiteHoteles();
        }

        return num;
    }

    private float pedirPorcentajeHIpoteca() {
        float num;
        try {
            num = Float.parseFloat(JOptionPane.showInputDialog(
                    "Ingresa el Porcentaje de Hipoteca por Propiedad entre 1--100")) / 100;
            if (num <= 0 || num > 1) {
                JOptionPane.showMessageDialog(null, "ERROR. Valor ingresado no valido");
                num = pedirPorcentajeHIpoteca();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "ERROR. Vuelve a intentarlo");
            num = pedirPorcentajeHIpoteca();
        }

        return num;
    }
    
  

    public String getNombreJuego() {
        return nombreJuego;
    }

    public void setNombreJuego(String nombreJuego) {
        this.nombreJuego = nombreJuego;
    }

    public int getCantJugadores() {
        return cantJugadores;
    }

    public void setCantJugadores(int cantJugadores) {
        this.cantJugadores = cantJugadores;
    }

    public int getCantDineroInicio() {
        return cantDineroInicio;
    }

    public void setCantDineroInicio(int cantDineroInicio) {
        this.cantDineroInicio = cantDineroInicio;
    }

    public int getCantDineroVuelta() {
        return cantDineroVuelta;
    }

    public void setCantDineroVuelta(int cantDineroVuelta) {
        this.cantDineroVuelta = cantDineroVuelta;
    }

    public int getCantDados() {
        return cantDados;
    }

    public void setCantDados(int cantDados) {
        this.cantDados = cantDados;
    }

    public int getLimiteCasas() {
        return limiteCasas;
    }

    public void setLimiteCasas(int limiteCasas) {
        this.limiteCasas = limiteCasas;
    }

    public int getLimiteHoteles() {
        return limiteHoteles;
    }

    public void setLimiteHoteles(int limiteHoteles) {
        this.limiteHoteles = limiteHoteles;
    }

    public float getPorcentajeHipo() {
        return porcentajeHipo;
    }

    public void setPorcentajeHipo(float porcentajeHipo) {
        this.porcentajeHipo = porcentajeHipo;
    }

    public JPanel getPanelPri() {
        return panelPri;
    }

    public void setPanelPri(JPanel panelPri) {
        this.panelPri = panelPri;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public int getAncho() {
        return ancho;
    }

    public void setAncho(int ancho) {
        this.ancho = ancho;
    }

    public Casilla[] getPosiCasillas() {
        return posiCasillas;
    }

    public void setPosiCasillas(Casilla[] posiCasillas) {
        this.posiCasillas = posiCasillas;
    }

    public JButton getBotonGuardar() {
        return botonGuardar;
    }

    public void setBotonGuardar(JButton botonGuardar) {
        this.botonGuardar = botonGuardar;
    }

    public Casilla getNuevaCasilla() {
        return nuevaCasilla;
    }

    public void setNuevaCasilla(Casilla nuevaCasilla) {
        this.nuevaCasilla = nuevaCasilla;
    }
    

}
