
package finalproyect;


public class Banco {

    public Banco() {
    }
    
    
}
