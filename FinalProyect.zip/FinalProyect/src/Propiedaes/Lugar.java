
package Propiedaes;

import Casillas.Propiedad;

public class Lugar extends Propiedad {

    public Lugar(int posicion, int x, int y) {
        super(posicion, x, y);
    }

    
     
    
}
