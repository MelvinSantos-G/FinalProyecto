
package Propiedaes;

import Casillas.Propiedad;


public class Estacion extends Propiedad{

    public Estacion(int posicion, int x, int y) {
        super(posicion, x, y);
    }

    
    
    
    
}
