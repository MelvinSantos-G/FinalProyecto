
package Propiedaes;

import Casillas.Propiedad;


public class ServicioBasico extends Propiedad {

    public ServicioBasico(int posicion, int x, int y) {
        super(posicion, x, y);
    }

    
    
}
