package Casillas;

import finalproyect.Casilla;
import finalproyect.Jugador;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Propiedad extends Casilla implements ActionListener {

    //private Jugador dueño;
    private Color kolor;
    private JLabel etiqueta2;
    private JTextField precio;
    private int compra;
    private int hipoteca;
    private  int tamaño; 
    private JFrame ventanaP;
    private JComboBox camColor;
    private JPanel panel;
    private JLabel etiqueta;
    private JButton aceptar;
    private JTextField nombrePropiedad;
    private final JLabel etiqueta1 = new JLabel("Nombre de la propiedad");
    private final String[] seleccion = {"Azul", "Gris", "Verde", "Naranja",
        "Rosado", "Rojo", "Amarillo"};
    private final Color[] color = {Color.BLUE, Color.GRAY, Color.GREEN,
        Color.ORANGE, Color.PINK, Color.RED, Color.YELLOW};

    public Propiedad(int posicion, int x, int y) {
        super(posicion, x, y);
    }

    public void editarPropiedad() {
        ventanaP = new JFrame();
        ventanaP.setTitle("" + getPosicion());
        ventanaP.setSize(350, 450);
        ventanaP.setResizable(false);
        ventanaP.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(null);

        camColor = new JComboBox(seleccion);
        camColor.setBounds(50, 20, 100, 30);

        etiqueta = new JLabel();
        etiqueta1.setBounds(20, 110, 200, 30);

        nombrePropiedad = new JTextField();
        nombrePropiedad.setBounds(50, 150, 100, 30);

        etiqueta2 = new JLabel("Cuanto vale esta propiedad");
        etiqueta2.setBounds(10, 200, 250, 30);

        precio = new JTextField();
        precio.setBounds(50, 250, 50, 30);

        aceptar = new JButton("Aceptar");
        aceptar.addActionListener(this);
        aceptar.setBounds(50, 300, 100, 30);
        addActionListener(this);

        nombrePropiedad = new JTextField();
        nombrePropiedad.setBounds(50, 150, 100, 30);

        panel.add(etiqueta2);
        panel.add(precio);
        panel.add(etiqueta1);
        panel.add(nombrePropiedad);
        panel.add(camColor);
        panel.add(aceptar);

        ventanaP.add(panel);
        ventanaP.setVisible(true);

    }

    public JLabel getCambicolor() {
        return etiqueta;
    }

    private void elegirColor(JComboBox camColor) {
        for (int i = 0; i < seleccion.length; i++) {
            if (camColor.getSelectedItem().equals(seleccion[i])) {
                kolor = color[i];
            }
        }
    }

    public JTextField getPrecio() {
        return precio;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
                  
            elegirColor(camColor);
            ventanaP.setVisible(false);
            etiqueta.setOpaque(true);
            etiqueta.setBounds(0, 0, getTamañoCasilla() - 1, 20);
            etiqueta.setBackground(kolor);
            etiqueta.setText(nombrePropiedad.getText());
            if (etiqueta.getText().length() == 0) {
                etiqueta.setText("" + (getPosicion() + 1));
            }
            if (kolor == Color.YELLOW || kolor == Color.PINK || kolor == Color.ORANGE) {
                etiqueta.setForeground(Color.BLACK);
            } else {
                etiqueta.setForeground(Color.WHITE);
            }
   

    }

}
