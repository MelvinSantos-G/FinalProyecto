
package Casillas;

import finalproyect.Casilla;
import java.awt.Color;


public class Carcel extends Casilla {
    private final String nombreCarcel= "Carcel";
    //private int posicion;

    public Carcel(int posicion, int x, int y) {
        super(posicion, x, y);
        iniciarCasillaCarcel(x, y);
    }
    private void iniciarCasillaCarcel(int x, int y){
        setBounds(x, y, getTamañoCasilla(), getTamañoCasilla());
        setBackground(Color.BLACK);
        setText(nombreCarcel);
    }
    

    

    

    
    
    
    public String getNombreCarcel() {
        return nombreCarcel;
    }
    
    
    

    

    
    
            
    
    
      
    
}
