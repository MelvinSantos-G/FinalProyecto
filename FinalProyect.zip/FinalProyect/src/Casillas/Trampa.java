
package Casillas;

import finalproyect.Casilla;
import java.awt.Color;


public class Trampa extends Casilla {

    public Trampa(int posicion, int x, int y) {
        super(posicion, x, y);
    }

    



    
}
