
package Casillas;

import finalproyect.Casilla;
import java.awt.Color;


public class Neutro extends Casilla {

    public Neutro(int posicion, int x, int y) {
        super(posicion, x, y);
        
    }

    
    

    
    
    
    
}
