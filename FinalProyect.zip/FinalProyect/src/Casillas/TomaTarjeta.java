
package Casillas;

import finalproyect.Casilla;
import java.awt.Color;

public class TomaTarjeta extends Casilla {

    public TomaTarjeta(int posicion, int x, int y) {
        super(posicion, x, y);
    }

    
    
    
    
    
}
