
package Casillas;

import finalproyect.Casilla;
import java.awt.Color;



public class Inicio extends Casilla {
    private int precioEntrada;
    private final String nombreCasila= "Inicio";

    public Inicio(int precioEntrada, int posicion, int x, int y) {
        super(posicion, x, y);
        this.precioEntrada = precioEntrada;
        iniciarCasillaInicio(x,y);
    } 
    
    
    private void iniciarCasillaInicio(int x, int y){
        setBounds(x, y, getTamañoCasilla(), getTamañoCasilla());
        setBackground(Color.LIGHT_GRAY);
        setText(nombreCasila);
    }

    public int getPrecioEntrada() {
        return precioEntrada;
    }

    public void setPrecioEntrada(int precioEntrada) {
        this.precioEntrada = precioEntrada;
    }

    public String getNombreCasila() {
        return nombreCasila;
    }

    public int incrementarAlPaso(int valor){
        valor += precioEntrada;
        return valor;
    }
    
        
     
    
    
    
    
    
}
